﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GroupSummaryTest
{
    public partial class MainWindow : Window
    {
        List<GroupedData> data;
        public ICollectionView View { get; set; }

        public MainWindow()
        {
            data = new List<GroupedData>()
            {
                new() { Level1 = "Receipts", Level2 = "Revenue", Level3 = "Sales", Level4 = "Product", Level5 = "Item 1", Amount = 1000 },
                new() { Level1 = "Receipts", Level2 = "Revenue", Level3 = "Sales", Level4 = "Product",Level5 = "Item 1", Amount = 1000 },
                new() { Level1 = "Receipts", Level2 = "Revenue", Level3 = "Sales", Level4 = "Product",Level5 = "Item 2", Amount = 1000 },
                new() { Level1 = "Receipts", Level2 = "Revenue", Level3 = "Sales", Level4 = "Product",Level5 = "Item 2", Amount = 1000 },
                new() { Level1 = "Receipts", Level2 = "Revenue", Level3 = "Sales", Level4 = "Service", Level5 = "Service 1", Amount = 1000 },
                new() { Level1 = "Receipts", Level2 = "Others", Level3 = "Some Other Source", Level4 = "Service", Level5 = "Service 2", Amount = 1000 },

                new() { Level1 = "Payments", Level2 = "Purchase", Level3 = "Assets", Level4 = "Fixed", Level5 = "Asset 1", Amount = 1000 },
                new() { Level1 = "Payments", Level2 = "Purchase", Level3 = "Assets", Level4 = "Fixed", Level5 = "Asset 1", Amount = 1000 },
                new() { Level1 = "Payments", Level2 = "Purchase", Level3 = "Assets", Level4 = "Fixed", Level5 = "Asset 2", Amount = 1000 },
                new() { Level1 = "Payments", Level2 = "Salaries", Level3 = "Labors", Level4 = "Permanent", Level5 = "Labor 1", Amount = 1000 },
                new() { Level1 = "Payments", Level2 = "Salaries", Level3 = "Labors", Level4 = "Permanent", Level5 = "Labor 2", Amount = 1000 },
                new() { Level1 = "Payments", Level2 = "Donation", Level3 = "Organisation", Level4 = "Philanthropic", Level5 = "Some Organization", Amount = 1000 },
            };
            View = CollectionViewSource.GetDefaultView(data);
            View.GroupDescriptions.Add(new PropertyGroupDescription("Level1"));
            View.GroupDescriptions.Add(new PropertyGroupDescription("Level2"));
            View.GroupDescriptions.Add(new PropertyGroupDescription("Level3"));
            View.GroupDescriptions.Add(new PropertyGroupDescription("Level4"));
            InitializeComponent();
            DataContext = this;
        }
    }

    public class GroupedData
    {
        public string Level1 { get; set; }
        public string Level2 { get; set; }
        public string Level3 { get; set; }
        public string Level4 { get; set; }
        public string Level5 { get; set; }
        public int Amount { get; set; }
    }

    public class SummaryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int sum = 0;
            var group = value as CollectionViewGroup;
            if (group.IsBottomLevel)
                sum = ((IEnumerable<object>)group.Items).OfType<GroupedData>().Sum(x => x.Amount);
            else foreach (CollectionViewGroup subGroup in group.Items)
                    if (subGroup.IsBottomLevel)
                        sum += ((IEnumerable<object>)subGroup.Items).OfType<GroupedData>().Sum(x => x.Amount);
                    else foreach (CollectionViewGroup sSubGroup in subGroup.Items)
                            if (sSubGroup.IsBottomLevel)
                                sum += ((IEnumerable<object>)sSubGroup.Items).OfType<GroupedData>().Sum(x => x.Amount);
                            else foreach (CollectionViewGroup ssSubGroup in sSubGroup.Items)
                                    sum += ((IEnumerable<object>)ssSubGroup.Items).OfType<GroupedData>().Sum(x => x.Amount);
            return sum;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
